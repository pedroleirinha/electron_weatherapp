window.$ = window.jQuery = require('jquery');

async function getWeather() {
    let city;

    city = arguments.length ? arguments[0] : $("#location").val();

    $(".spinner").fadeIn("fast");

    var result = await makeRequest(getRequestURL(city)).then((response) => {
        showInfo(response);
    }).catch((error) => {
        alert("Coudnt retrieve any information. try again!");
    });
    $(".spinner").fadeOut("fast");
}

function getRequestURL(city) {
    const APIKEY = "9f56df1c095f61ff1204cf06c4e767ee";
    return (`http://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&APPID=${APIKEY}`);
}

function makeRequest(url) {
    return fetch(url)
        .then((response) => {
            return response.json();
        });
}

$(function () {
    $("#search").on("click", () => {
        getWeather();
    });

    $("#location").keyup((key) => {
        if (key.keyCode == 13) {
            getWeather();
        }

    });

    getWeather("Alverca do ribatejo");
});

function showInfo(jsonObject) {

    let temperature = jsonObject["main"]["temp"];
    let minTemp = jsonObject["main"]["temp_max"];
    let maxTemp = jsonObject["main"]["temp_min"];

    let mainWeather = jsonObject["weather"][0]["main"];
    let weatherDescription = jsonObject["weather"][0]["description"];
    let cityName = jsonObject["name"];
    let country = jsonObject["sys"]["country"];
    let image = `http://openweathermap.org/img/w/${jsonObject["weather"][0]["icon"]}.png`;


    $("#weatherImage").attr("src", image);
    $("#cityName").html(`${cityName}, ${country}`);
    $("#currentTemp").html(parseInt(temperature) + " ºC");
    $("#minTemp").html(parseInt(minTemp) + " ºC");
    $("#maxTemp").html(parseInt(maxTemp) + " ºC");
    $("#mainWeather").html(mainWeather);
    $("#weatherDescription").html(weatherDescription);
}

